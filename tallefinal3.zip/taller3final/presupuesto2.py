class Envio:
    def _init_(self, peso_kg, distancia_km):
        
        self.peso_kg = peso_kg
        self.distancia_km = distancia_km

    def calcular_costo(self, monto_base):
        return monto_base

class EnvioEstandar(Envio):
    def calcular_costo(self, monto_base):
        
        recargo = monto_base * 0.05
        return monto_base + recargo

class EnvioExpress(Envio):
    def calcular_costo(self, monto_base):
        
        recargo = monto_base * 0.15
        return monto_base + recargo


mis_envios = [
    EnvioEstandar(peso_kg=10, distancia_km=50),
    EnvioExpress(peso_kg=2, distancia_km=100),
    EnvioEstandar(peso_kg=5, distancia_km=10)
]

monto_base_prueba = 1000

for envio in mis_envios:
    print(f"Tipo: {type(envio)._name_} | Costo Final: {envio.calcular_costo(monto_base_prueba)}")