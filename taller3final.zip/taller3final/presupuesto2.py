class Envio:
    def _init_(self, peso_kg, distancia_km):
        # Atributos de la clase base[span_15](start_span)[span_15](end_span)
        self.peso_kg = peso_kg
        self.distancia_km = distancia_km

    def calcular_costo(self, monto_base):
        return monto_base

class EnvioEstandar(Envio):
    def calcular_costo(self, monto_base):
        # Aplica un recargo del 5% sobre el monto base[span_16](start_span)[span_16](end_span)
        recargo = monto_base * 0.05
        return monto_base + recargo

class EnvioExpress(Envio):
    def calcular_costo(self, monto_base):
        # Aplica un recargo del 15% debido al servicio prioritario[span_17](start_span)[span_17](end_span)
        recargo = monto_base * 0.15
        return monto_base + recargo

# --- Prueba del Ejercicio 2 ---
# Lista mixta de envíos[span_18](start_span)[span_18](end_span)
mis_envios = [
    EnvioEstandar(peso_kg=10, distancia_km=50),
    EnvioExpress(peso_kg=2, distancia_km=100),
    EnvioEstandar(peso_kg=5, distancia_km=10)
]

monto_base_prueba = 1000

# Recorre la colección ejecutando el método calcular_costo para evidenciar el comportamiento polimórfico[span_19](start_span)[span_19](end_span)
for envio in mis_envios:
    print(f"Tipo: {type(envio)._name_} | Costo Final: {envio.calcular_costo(monto_base_prueba)}")