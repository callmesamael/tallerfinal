class Producto:
    def _init_(self, nombre):
        self.__nombre = nombre
        # Lista que almacena los precios a los que se ha vendido el producto[span_5](start_span)[span_5](end_span)
        self.__precios_historicos = [] 

    @property
    def precio(self):
        return self.__precios_historicos

    @precio.setter
    def precio(self, nuevo_precio):
        # Impedir que se registren valores negativos o superiores a $10,000[span_6](start_span)[span_6](end_span)
        if nuevo_precio < 0 or nuevo_precio > 10000:
            # Emite una advertencia y no altera el registro[span_7](start_span)[span_7](end_span)
            print(f"Advertencia: El precio {nuevo_precio} no es válido. Debe estar entre 0 y 10,000.")
        else:
            self.__precios_historicos.append(nuevo_precio)

    def calcular_promedio(self):
        # Método para calcular el precio promedio del producto[span_8](start_span)[span_8](end_span)
        if len(self.__precios_historicos) == 0:
            return 0
        return sum(self._precios_historicos) / len(self._precios_historicos)

# --- Prueba del Ejercicio 1 ---
mi_producto = Producto("Teclado")
mi_producto.precio = 5000     # Se registra normal
mi_producto.precio = -200     # Emite advertencia
mi_producto.precio = 15000    # Emite advertencia
mi_producto.precio = 4000     # Se registra normal

print("Promedio de precios:", mi_producto.calcular_promedio())